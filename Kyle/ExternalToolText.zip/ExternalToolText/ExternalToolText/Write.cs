﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalToolText
{
    class Write
    {
        public void Writing(string type, StreamWriter strm, bool makeFile, string input, int result)
        {
            int n;
            while(makeFile == true)
            {
                //get user input, write to file - start with type at unique name
                strm.Write(type + ",");
                Console.Write("\nA name to identify this object/character: ");
                input = Console.ReadLine();
                strm.Write(input + ",");

                //if type is a character or other, ask for health/damage 
                if (type == "enemy" || type == "player" || type == "other")
                {
                Health:
                    Console.Write("\nHealth (0 - 200): ");
                    input = Console.ReadLine();

                    //make sure its an integer
                    if (int.TryParse(input, out result))
                    {
                        //check value
                        if (result >= 0 && result <= 200)
                        {
                            strm.Write(input + ",");
                        }
                        else
                        {
                            Console.WriteLine("\n0 to 200 please");
                            goto Health;
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter a number.");
                        goto Health;
                    }
                Damage:
                    Console.Write("\nDamage (0 - 100): ");
                    input = Console.ReadLine();

                    //make sure its an integer
                    if (int.TryParse(input, out result))
                    {
                        if (result >= 0 && result <= 100)
                        {
                            strm.Write(input + ",");
                        }
                        else
                        {
                            Console.WriteLine("\n0 to 100 please");
                            goto Damage;
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter a number.");
                        goto Damage;
                    }
                }

                //get damage if weapon
                else if(type == "weapon")
                {
                Damage:
                    Console.Write("\nDamage (0 - 100): ");
                    input = Console.ReadLine();

                    //make sure its an integer
                    if (int.TryParse(input, out result))
                    {
                        if (result >= 0 && result <= 100)
                        {
                            strm.Write(input + ",");
                        }
                        else
                        {
                            Console.WriteLine("\n0 to 100 please");
                            goto Damage;
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter a number.");
                        goto Damage;
                    }
                }

                //next is location and dimensions, for all
            Xloc:
                Console.Write("\nX Location: ");
                input = Console.ReadLine();
                if (int.TryParse(input, out result))
                {
                    strm.Write(input + ",");
                }
                else
                {
                    Console.WriteLine("\nPlease enter a number.");
                    goto Xloc;
                }
                
            Yloc:               
                Console.Write("\nY Location: ");
                input = Console.ReadLine();
                if (int.TryParse(input, out result))
                {
                    strm.Write(input + ",");
                }
                else
                {
                    Console.WriteLine("\nPlease enter a number.");
                    goto Yloc;
                }
            Width:
                Console.Write("\nWidth: ");
                input = Console.ReadLine();
                if (int.TryParse(input, out result))
                {
                    strm.Write(input + ",");
                }
                else
                {
                    Console.WriteLine("\nPlease enter a number.");
                    goto Width;
                }
            Height:
                Console.Write("\nHeight: ");
                input = Console.ReadLine();
                if (int.TryParse(input, out result))
                {
                    strm.Write(input);
                }
                else
                {
                    Console.WriteLine("\nPlease enter a number.");
                    goto Height;
                }

                //check to see if they want to keep adding characters
            MakeMore:
                Console.Write("\nWould you like to add another " + type + " ('yes' or 'no'): ");
                input = Console.ReadLine();
                switch (input)
                {
                    case "yes": //loop
                        strm.WriteLine();
                        break;

                    case "no": //set done to true, leave loop
                        Console.WriteLine();
                        makeFile = false;
                        return;

                    default:
                        Console.WriteLine("\nTry again.");
                        goto MakeMore;
                }
            } // end inner loop:
            Console.WriteLine("Something was wrong");          
        }
    }
}
