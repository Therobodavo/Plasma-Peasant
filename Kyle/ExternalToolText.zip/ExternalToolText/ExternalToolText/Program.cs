﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ExternalToolText
{
    class Program
    {
        static void Main(string[] args)
        {
        Start:
            string filename;
            Console.Write("What character file would you like to create: ");
            filename = Console.ReadLine();
            StreamWriter strm = new StreamWriter(new FileStream(filename, FileMode.Create));
            //get user input
            string input;
            Console.Write("Health (0+): ");
            input = Console.ReadLine();
            strm.WriteLine(input);
            Console.Write("Damage: ");
            input = Console.ReadLine();
            strm.WriteLine(input);
            Console.Write("X Location: ");
            input = Console.ReadLine();
            strm.WriteLine(input);
            Console.Write("Y Location: ");
            input = Console.ReadLine();
            strm.WriteLine(input);
        exit:
            //ask if that is all
            Console.WriteLine("Would you like to enter more? (yes or no)");
            string answer = Console.ReadLine();
            switch (answer)
            {
                case "yes": goto Start;
                case "no":
                    Console.WriteLine("Closing stream.");
                    break;
                default:
                    Console.WriteLine("Try again.");
                    goto exit;
            }
            //close stream
            strm.Close();
        }
    }
}
