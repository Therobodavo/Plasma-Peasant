﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Kyle Fasanella
//Section 1
//External Tool - text files
namespace ExternalToolText
{
    class Program
    {
        static void Main(string[] args)
        {
            //value for checking if need to leave outer loop/finish program
            bool done = false;
            //attributes
            string filename;
            string input = "";
            string type;
            int result = 0;
            StreamWriter strm;
            bool makeFile;
            Menu menu = new Menu();
            Write writ = new Write();

            Console.WriteLine("Welcome!");

            //outer loop
            while (done == false)
            {
                makeFile = true;
                type = menu.Decide();
                //get filename to create
                Console.Write("\nName of file (no need to enter '.txt'): ");
                filename = Console.ReadLine() + ".txt";
                //if file doesnt exist, make new one
                if (File.Exists(filename) != true)
                {
                    strm = new StreamWriter(new FileStream(filename, FileMode.Create));
                }
                else //append one that exists
                {
                    strm = new StreamWriter(new FileStream(filename, FileMode.Append));
                    strm.WriteLine("");
                }

                writ.Writing(type, strm, makeFile, input, result);

                //exiting program/going back and doing another file
                Exit:
                //ask if that is all
                Console.Write("\nWould you like to make another file ('yes' or 'no'): ");
                input = Console.ReadLine();
                //decide what to do
                switch (input)
                {
                    case "yes": //loop
                        break;

                    case "no": //set done to true, leave loop
                        Console.WriteLine("\nClosing stream.");
                        done = true;
                        break;

                    default:
                        Console.WriteLine("\nTry again.");
                        goto Exit;
                }

                //close stream
                strm.Close();
            } // end outer loop
        } // end main
    } // end class
}
