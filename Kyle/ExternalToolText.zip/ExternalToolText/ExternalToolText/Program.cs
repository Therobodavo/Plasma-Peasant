﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Kyle Fasanella
//Section 1
//External Tool - text files
namespace ExternalToolText
{
    class Program
    {
        static void Main(string[] args)
        {
            //value for checking if need to leave outer loop/finish program
            bool done = false;
            //attributes
            string filename;
            string input = "";
            string type;
            int result = 0;
            StreamWriter strm;
            bool makeFile;
            Menu menu = new Menu();
            Write writ = new Write();

            Console.WriteLine("Welcome!");

            //outer loop
            while (done == false)
            {
                makeFile = true;

                //explain values/input
                Console.WriteLine("\n***************************************************************************************");
                Console.WriteLine("\nLevel: what level the player/ enemy will be in (type 'lvl' only for now)\nX / Y: coordinates for rectangle\nWidth / Height: also for rectangle");
                Console.WriteLine("Projectile Speed: speed that pojectile will go at\nDamage: damage done; for item: damage added to player damage when picked up\nHealth: health to add to player\nValue: value to apply to item\n");
                Console.WriteLine("To add multiple types to one file:\nAppend an existing file by typing its name when asked to type a name.\nOr answer yes when asked if you want to add another object of a different type,\nwhich occours when you answer no to creating more of the same type\n");
                Console.WriteLine("***************************************************************************************\n");

                type = menu.Decide();
                //get filename to create
                Console.Write("\nName of file (no need to enter '.txt'): ");
                filename = Console.ReadLine() + ".txt";
                //if file doesnt exist, make new one
                if (File.Exists(filename) != true)
                {
                    strm = new StreamWriter(new FileStream(filename, FileMode.Create));
                }
                else //append one that exists
                {
                    strm = new StreamWriter(new FileStream(filename, FileMode.Append));
                    strm.WriteLine("");
                }

                writ.Writing(type, strm, makeFile, input, result);

                //exiting program/going back and doing another file
                Exit:
                //ask if that is all
                Console.Write("Would you like to make another file ('yes' or 'no'): ");
                input = Console.ReadLine();
                //decide what to do
                switch (input)
                {
                    case "yes": //loop
                        break;

                    case "no": //set done to true, leave loop
                        Console.WriteLine("\nClosing stream.");
                        done = true;
                        break;

                    default:
                        Console.WriteLine("\nTry again.");
                        goto Exit;
                }

                //close stream
                strm.Close();
            } // end outer loop
        } // end main
    } // end class
}
