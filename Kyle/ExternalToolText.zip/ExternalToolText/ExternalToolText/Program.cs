﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Kyle Fasanella
//Section 1
//External Tool - text files
namespace ExternalToolText
{
    class Program
    {
        static void Main(string[] args)
        {
            //value for checking if need to leave outer loop/finish program
            bool done = false;
            //attributes
            string filename;
            string input;
            string type;
            StreamWriter strm;
            bool makeFile;
            Menu menu = new Menu();

            Console.WriteLine("Welcome!");

            //outer loop
            while (done == false)
            {
                makeFile = true;
                type = menu.Decide();
                //get filename to create
                Console.Write("Name of file (no need to enter '.txt'): ");
                filename = Console.ReadLine() + ".txt";
                //if file doesnt exist, make new one
                if (File.Exists(filename) != true)
                {
                    strm = new StreamWriter(new FileStream(filename, FileMode.Create));
                }
                else //append one that exists
                {
                    strm = new StreamWriter(new FileStream(filename, FileMode.Append));
                    strm.WriteLine("");
                }

                //decide what to ask for, and do so
                switch (type)
                {
                    case "enemy":
                        //inner loop - making numerous characters
                        while (makeFile == true)
                        {
                            //get user input, write to file     
                            strm.Write(type + ",");
                            Console.Write("A name to identify this object/character: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Health (0+): ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Damage: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("X Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Y Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Width: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Height: ");
                            input = Console.ReadLine();
                            strm.Write(input);
                        //check to see if they want to keep adding characters
                        MakeMore:
                            Console.Write("Would you like to add another " + type + " ('yes' or 'no'): ");
                            input = Console.ReadLine();
                            switch (input)
                            {
                                case "yes": //loop
                                    strm.WriteLine();
                                    break;

                                case "no": //set done to true, leave loop
                                    Console.WriteLine();
                                    makeFile = false;
                                    break;

                                default:
                                    Console.WriteLine("Try again.");
                                    goto MakeMore;
                            }
                        } // end inner loop
                        break;
                    case "player":
                        //inner loop - making numerous characters
                        while (makeFile == true)
                        {
                            //get user input, write to file     
                            strm.Write(type + ",");
                            Console.Write("A name to identify this object/character: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Health (0+): ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Damage: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("X Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Y Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Width: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Height: ");
                            input = Console.ReadLine();
                            strm.Write(input);
                        //check to see if they want to keep adding characters
                        MakeMore:
                            Console.Write("Would you like to add another " + type + " ('yes' or 'no'): ");
                            input = Console.ReadLine();
                            switch (input)
                            {
                                case "yes": //loop
                                    strm.WriteLine();
                                    break;

                                case "no": //set done to true, leave loop
                                    Console.WriteLine();
                                    makeFile = false;
                                    break;

                                default:
                                    Console.WriteLine("Try again.");
                                    goto MakeMore;
                            }                    
                        } // end inner loop
                        break;
                    case "weapon":
                        //inner loop - making numerous characters
                        while (makeFile == true)
                        {
                            //get user input, write to file     
                            strm.Write(type + ",");
                            Console.Write("A name to identify this object/character: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Damage: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("X Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Y Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Width: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Height: ");
                            input = Console.ReadLine();
                            strm.Write(input);
                        //check to see if they want to keep adding characters
                        MakeMore:
                            Console.Write("Would you like to add another " + type + " ('yes' or 'no'): ");
                            input = Console.ReadLine();
                            switch (input)
                            {
                                case "yes": //loop
                                    strm.WriteLine();
                                    break;

                                case "no": //set done to true, leave loop
                                    Console.WriteLine();
                                    makeFile = false;
                                    break;

                                default:
                                    Console.WriteLine("Try again.");
                                    goto MakeMore;
                            }
                        } // end inner loop
                        break;
                    case "wall":
                        //inner loop - making numerous characters
                        while (makeFile == true)
                        {
                            //get user input, write to file     
                            strm.Write(type + ",");
                            Console.Write("A name to identify this object/character: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("X Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Y Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Width: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Height: ");
                            input = Console.ReadLine();
                            strm.Write(input);
                        //check to see if they want to keep adding characters
                        MakeMore:
                            Console.Write("Would you like to add another " + type + " ('yes' or 'no'): ");
                            input = Console.ReadLine();
                            switch (input)
                            {
                                case "yes": //loop
                                    strm.WriteLine();
                                    break;

                                case "no": //set done to true, leave loop
                                    Console.WriteLine();
                                    makeFile = false;
                                    break;

                                default:
                                    Console.WriteLine("Try again.");
                                    goto MakeMore;
                            }
                        } // end inner loop
                        break;
                    case "floor":
                        //inner loop - making numerous characters
                        while (makeFile == true)
                        {
                            //get user input, write to file     
                            strm.Write(type + ",");
                            Console.Write("A name to identify this object/character: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("X Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Y Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Width: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Height: ");
                            input = Console.ReadLine();
                            strm.Write(input);
                        //check to see if they want to keep adding characters
                        MakeMore:
                            Console.Write("Would you like to add another " + type + " ('yes' or 'no'): ");
                            input = Console.ReadLine();
                            switch (input)
                            {
                                case "yes": //loop
                                    strm.WriteLine();
                                    break;

                                case "no": //set done to true, leave loop
                                    Console.WriteLine();
                                    makeFile = false;
                                    break;

                                default:
                                    Console.WriteLine("Try again.");
                                    goto MakeMore;
                            }
                        } // end inner loop
                        break;
                    case "other":
                        //inner loop - making numerous characters
                        while (makeFile == true)
                        {
                            //get user input, write to file     
                            strm.Write(type + ",");
                            Console.Write("A name to identify this object/character: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Health (0+): ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Damage: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("X Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Y Location: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Width: ");
                            input = Console.ReadLine();
                            strm.Write(input + ",");
                            Console.Write("Height: ");
                            input = Console.ReadLine();
                            strm.Write(input);
                        //check to see if they want to keep adding characters
                        MakeMore:
                            Console.Write("Would you like to add another " + type + " ('yes' or 'no'): ");
                            input = Console.ReadLine();
                            switch (input)
                            {
                                case "yes": //loop
                                    strm.WriteLine();
                                    break;

                                case "no": //set done to true, leave loop
                                    Console.WriteLine();
                                    makeFile = false;
                                    break;

                                default:
                                    Console.WriteLine("Try again.");
                                    goto MakeMore;
                            }
                        } // end inner loop
                        break;
                    default:
                        Console.WriteLine("Something was wrong");
                        break;
                }

                //exiting program/going back and doing another file
                Exit:
                //ask if that is all
                Console.Write("Would you like to make another file ('yes' or 'no'): ");
                input = Console.ReadLine();
                //decide what to do
                switch (input)
                {
                    case "yes": //loop
                        break;

                    case "no": //set done to true, leave loop
                        Console.WriteLine("Closing stream.");
                        done = true;
                        break;

                    default:
                        Console.WriteLine("Try again.");
                        goto Exit;
                }

                //close stream
                strm.Close();
            } // end outer loop
        } // end main
    } // end class
}
