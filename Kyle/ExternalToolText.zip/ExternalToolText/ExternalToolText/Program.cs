﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Kyle Fasanella
//Section 1
//External Tool - text files
namespace ExternalToolText
{
    class Program
    {
        static void Main(string[] args)
        {
            //value for checking if need to leave outer loop/finish program
            bool done = false;
            string filename;
            string input;
            StreamWriter strm;
            bool makeFile;

            //outer loop
            while (done == false)
            {
                makeFile = true;
                //get filename to create
                Console.Write("What character file would you like to create (.txt at end): ");
                filename = Console.ReadLine();
                strm = new StreamWriter(new FileStream(filename, FileMode.Create));

                //inner loop - making numerous characters
                while (makeFile == true)
                {
                    //get user input, write to file              
                    Console.Write("Health (0+): ");
                    input = Console.ReadLine();
                    strm.Write(input + ",");
                    Console.Write("Damage: ");
                    input = Console.ReadLine();
                    strm.Write(input + ",");
                    Console.Write("X Location: ");
                    input = Console.ReadLine();
                    strm.Write(input + ",");
                    Console.Write("Y Location: ");
                    input = Console.ReadLine();
                    strm.Write(input + ",");
                    Console.Write("Width: ");
                    input = Console.ReadLine();
                    strm.Write(input + ",");
                    Console.Write("Height: ");
                    input = Console.ReadLine();
                    strm.Write(input);
                    //check to see if they want to keep adding characters
                    MakeMore:
                    Console.Write("Would you like to add another character ('yes' or 'no'): ");
                    input = Console.ReadLine();
                    switch (input)
                    {
                        case "yes": //loop
                            strm.WriteLine();
                            break;

                        case "no": //set done to true, leave loop
                            Console.WriteLine();
                            makeFile = false;
                            break;

                        default:
                            Console.WriteLine("Try again.");
                            goto MakeMore;
                    }
                } // end inner loop

                //exiting program/going back and doing another file
                Exit:
                //ask if that is all
                Console.Write("Would you like to make another file ('yes' or 'no'): ");
                input = Console.ReadLine();
                //decide what to do
                switch (input)
                {
                    case "yes": //loop
                        break;

                    case "no": //set done to true, leave loop
                        Console.WriteLine("Closing stream.");
                        done = true;
                        break;

                    default:
                        Console.WriteLine("Try again.");
                        goto Exit;
                }

                //close stream
                strm.Close();
            } // end outer loop
        } // end main
    } // end class
}
