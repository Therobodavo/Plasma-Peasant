﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kyle Fasanella
//Section 1
//External Tool - deciding what file to make
namespace ExternalToolText
{
    class Menu
    {
        public string Decide()
        {
            //attributes
            string input;

            //Have user decide what to make
            Start:
            Console.WriteLine("\nWhat kind of object would you like to create? (type number)");
            Console.WriteLine("\ncharacter(1)\nobject(2)");
            input = Console.ReadLine();
            switch (input)
            {
                case "1":
                    One:
                    Console.WriteLine("\nType the word:\nenemy\nplayer\nother");
                    input = Console.ReadLine();
                    if (input == "enemy" || input == "player" || input == "other")
                    {
                        return input;
                    }
                    else
                    {
                        goto One;
                    }
                case "2":
                    Two:
                    Console.WriteLine("\nType the word:\nweapon\nwall\nfloor\nother");
                    input = Console.ReadLine();
                    if (input == "weapon" || input == "wall" || input == "floor" || input == "other")
                    {
                        return input;
                    }
                    else
                    {
                        goto Two;
                    }    
                default: Console.WriteLine("\nTry Again");
                    goto Start;
            }
        }       
    }
}
