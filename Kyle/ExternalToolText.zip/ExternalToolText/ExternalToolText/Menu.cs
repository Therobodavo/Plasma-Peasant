﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Kyle Fasanella
//Section 1
//External Tool - deciding what file to make
namespace ExternalToolText
{
    class Menu
    {
        public string Decide()
        {
            //attributes
            string input;

            //Have user decide what to make
            Start:
            Console.WriteLine("\nWhat kind of object would you like to create? (type word)");
            Console.WriteLine("\ncharacter\nweapon\nitem");
            input = Console.ReadLine();
            switch (input)
            {
                //if character, ask if enemy or player
                case "character":
                One:
                    Console.WriteLine("\nType the word:\nenemy\nplayer");
                    input = Console.ReadLine();
                    if (input == "enemy" || input == "player")
                    {
                        return input;
                    }
                    else
                    {
                        Console.WriteLine("\nTry again");
                        goto One;
                    }
                //if weapon, ask what kind
                case "weapon":
                Two:
                    Console.WriteLine("\nType the word:\nranged\nmelee");
                    input = Console.ReadLine();
                    if (input == "ranged" || input == "melee")
                    {
                        return input;
                    }
                    else
                    {
                        Console.WriteLine("\nTry again");
                        goto Two;
                    }
                //if item
                case "item":
                    return input;     
                //default: go back to start
                default: Console.WriteLine("\nTry again");
                    goto Start;
            }
        }       
    }
}
