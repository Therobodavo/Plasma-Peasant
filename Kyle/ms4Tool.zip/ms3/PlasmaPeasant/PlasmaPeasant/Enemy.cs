﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class Enemy:Characters
    {
        // rangedweap
        RangedWeap rangeWeap;
        // shootval to keep enemy from shooting too fast
        int fireRate;
        // int value for how long since a direction change
        int directRate;
        // random movement for now
        Random rgen = new Random();

        // default constructor
        public Enemy(Level lvl, int x, int y, int width, int height, int hp, int speed, int basedmg) : base(lvl,x, y, width, height, hp, speed, basedmg)
        {
            rangeWeap = new RangedWeap(this, lvl, x, y, this.Damage, 100, 10);
            fireRate = 100;
            directRate = 450;
        }

        // randomly move for the time
        public void Move()
        {
            // check which direction to move
            // only runs after a set time of not running
            if(directRate >= 50)
            {
                int dir = rgen.Next(0, 8);
                if (dir == 0) { this.Motion = Direction.Down; }
                if (dir == 1) { this.Motion = Direction.Down_Left; }
                if (dir == 2) { this.Motion = Direction.Down_Right; }
                if (dir == 3) { this.Motion = Direction.Left; }
                if (dir == 4) { this.Motion = Direction.Right; }
                if (dir == 5) { this.Motion = Direction.Up; }
                if (dir == 6) { this.Motion = Direction.Up_Left; }
                if (dir == 7) { this.Motion = Direction.Up_Right; }
                directRate = 0;
            }

            // move based one direction of motion
            // TURNED OFF FOR SHOOT TEST
            /*
            if (this.Motion == Direction.Up) { Y = Y - 5; }
            if (this.Motion == Direction.Up_Left) { Y = Y - 5; X = X - 5; }
            if (this.Motion == Direction.Up_Right) { Y = Y - 5; X = X + 5; }
            if (this.Motion == Direction.Right) { X = X + 5; }
            if (this.Motion == Direction.Left) { X = X -5; }
            if (this.Motion == Direction.Down) { Y = Y + 5; }
            if (this.Motion == Direction.Down_Left) { Y = Y + 5; X = X - 5; }
            if (this.Motion == Direction.Down_Right) { Y = Y + 5; X = X + 5; }
            */

            // has weapons position follow the player
            rangeWeap.X = this.X;
            rangeWeap.Y = this.Y;

            //save last postion
            int lastPosX = X;
            int lastPosY = Y;

            //Checks if player collides with objects
            if (lvl.CheckCollisionObjects(this))
            {
                X = lastPosX;
                Y = lastPosY;
            }
            directRate++;
        }

        // shooting enemy
        // enemy always shoots when it can
        public void Shoot()
        {
            if (fireRate > rangeWeap.FireRate)
            {
                rangeWeap.Attack();
                fireRate = 0;
            }
            else
            {
                fireRate++;
            }
        }

        // check if being hit
        public void CheckHits()
        {
            Projectile i = lvl.CheckCollisionProjectiles(this);
            if (i == null)
            {
                return;
            }
            else
            {
                this.Health = -i.Damage;
            }
        }

        // Enemy update
        public override void Update()
        {
            this.CheckHits();
            this.Shoot();
            this.Move();
            base.Update();
        }
    }
}
