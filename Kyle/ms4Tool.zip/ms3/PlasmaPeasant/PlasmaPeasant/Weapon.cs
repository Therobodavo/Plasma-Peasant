﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class Weapon:Items
    {
        protected Characters host;
        public Weapon(Characters host, Level lvl,int x, int y, int damage) : base(lvl, x, y, 0, 0, damage)
        {
            this.host = host;
        }
        public virtual void Attack()
        {

        }
    }
}
