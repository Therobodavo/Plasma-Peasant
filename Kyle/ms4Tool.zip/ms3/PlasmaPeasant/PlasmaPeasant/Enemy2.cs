﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaPeasant
{
    class Enemy2 : Enemy
    {
        public Enemy2(Level lvl, int x, int y, int width, int height, int hp, int speed) : base(lvl, x, y, width, height, hp, speed)
        {
        }
    }
}
