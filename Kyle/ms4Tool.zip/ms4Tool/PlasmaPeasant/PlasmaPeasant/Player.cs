﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
/*
 * GDAPS 2 Online Section 2
 * Player class
 * Programmed by Fred and David
 */
namespace PlasmaPeasant
{
    class Player:Characters
    {
        // attributes to save kyboard values
        KeyboardState kstate;
        KeyboardState oldstate;
        int lastPosX;
        int lastPosY;

        // accesor for kstate
        public KeyboardState Kstate { get { return kstate; } }

        // int value to set how often to shoot
        int fireRate;

        // attribute for bag
        Bag bag = new Bag(20);

        // weapons
        // melee weapon
        // ranged weapon
        RangedWeap rangeWeap;

        // basic constructor
        public Player(Level lvl, int x, int y, int width, int height, int hp, int speed, int basedmg) : base(lvl, x, y, width, height, hp, speed, basedmg)
        {
            fireRate = 1000;
            fileTexture = "Peasant";
            // test ranged weapon
            rangeWeap = new RangedWeap(this, lvl, x, y, this.Damage, 25, 10);

        }

        public void Control()
        {
            // save last keyboard state
            oldstate = kstate;

            //save last postion
            lastPosX = X;
            lastPosY = Y;

            //Input from user (moving and shooting)
            GetInput();

            // has weapons position follow the player
            rangeWeap.X = this.X;
            rangeWeap.Y = this.Y;

            //Checks if player collides
            if (lvl.CheckCollisionObjects(this))
            {
                X = lastPosX;
                Y = lastPosY;
            }
            // check if player collides with enemies
            if (lvl.CheckCollisionEnemy(this))
            {
                X = lastPosX;
                Y = lastPosY;
                health = -1;
            }
        }

        // shooting controls
        public bool CanShoot()
        {
            // shooting controls
            if (fireRate > rangeWeap.FireRate)
            {
                if (kstate.IsKeyDown(Keys.Space))
                {
                    fireRate = 0;
                    return true;
                }
                else
                {
                    fireRate = fireRate + 1;
                    return false;
                }
            }
            fireRate = fireRate + 1;
            return false;
        }
        public void GetInput()
        {

            if (kstate.IsKeyDown(Keys.Escape))
            {
                lvl.NeedsReset = true;
                Game1.currentScreen = Game1.GameStates.MainScreen;
            }
            // save keyboard state
            kstate = Keyboard.GetState();

            // movement controls
            if (kstate.IsKeyDown(Keys.W))
            {
                Y = Y - speed;
            }
            if (kstate.IsKeyDown(Keys.A))
            {
                X = X - speed;
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                Y = Y + speed;
            }
            if (kstate.IsKeyDown(Keys.D))
            {
                X = X + speed;
            }

            //Direction
            // code to figure out where player is aiming
            if (kstate.IsKeyDown(Keys.W))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Up_Left; }
                else if (kstate.IsKeyDown(Keys.D)) { motion = Direction.Up_Right; }
                else { motion = Direction.Up; }
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Down_Left; }
                else if (kstate.IsKeyDown(Keys.D)) { motion = Direction.Down_Right; }
                else { motion = Direction.Down; }
            }
            if (kstate.IsKeyDown(Keys.A) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { motion = Direction.Left; }
            if (kstate.IsKeyDown(Keys.D) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.A) == false) { motion = Direction.Right; }

            // if no keys are down shoots straight up
            //if (kstate.IsKeyDown(Keys.A) == false && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { motion = Direction.Up; }

            if (CanShoot() && kstate.IsKeyDown(Keys.Space))
            {
                rangeWeap.Attack();
            }

            // TEST USE ITEM FROM BAG
            // B to use first item in Bag
            if(kstate.IsKeyDown(Keys.B) && oldstate.IsKeyDown(Keys.B) != true)
            {
                this.TestItem();
            }
        }

        // check if collided with objects to pick it up
        public void CheckItem()
        {
            Items i = lvl.CheckCollisionItems(this);
            if(i == null) { return; }
            else
            {
                bag.PickUp(i);
            }
        }

        // check if being hit
        public void CheckHits()
        {
            Projectile i = lvl.CheckCollisionProjectiles(this);
            if(i == null)
            {
                return;
            }
            else
            {
                this.Health = -i.Damage;
            }
        }

        // TEST METHOD USES FIRST ITEM IN BAG
        public void TestItem()
        {
            if(bag.Count == 0)
            {
                return;
            }
            this.UseItem(0);
        }

        // item use
        public void UseItem(int i)
        {
            // gets item from bag
            Items item = bag.Use(i);
            // applies item values to player
            this.Health = item.Health;
            this.Speed = item.Speed;
            this.Damage = item.Damage;
        }

        public override void Update()
        {
            this.CheckHits();
            this.CheckItem();
            this.Control();
            base.Update();
        }
    }
}
