﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaPeasant
{
    class Enemy1 : Enemy
    {
        public Enemy1(Level lvl, int x, int y, int width, int height, int hp, int speed) : base(lvl, x, y, width, height, hp, speed)
        {
        }
    }
}
