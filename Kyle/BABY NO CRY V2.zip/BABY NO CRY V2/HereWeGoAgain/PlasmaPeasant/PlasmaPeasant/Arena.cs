﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;
/*
* Arena Demo
* (Wave Defence)
* by (Temporary Group Lead) Fred
*/

namespace PlasmaPeasant
{
    class Arena:Level
    {
        // attributes
        private int wave;
        private Random rgen;
        // keeps track if an item dropped
        private bool drop;
        // background texture
        Texture2D background;

        // WALLS
        // vertical walls
        public Objects wall1;
        public Objects wall2;
        public Objects wall3;
        public Objects wall4;
        public Objects wall5;
        public Objects wall6;
        public Objects wall7;
        public Objects wall8;
        public Objects wall9;
        public Objects wall10;
        public Objects wall11;

        public Objects wall21;
        public Objects wall22;
        public Objects wall23;
        public Objects wall24;
        public Objects wall25;
        public Objects wall26;
        public Objects wall27;
        public Objects wall28;
        public Objects wall29;
        public Objects wall30;
        public Objects wall31;

        // horizontal walls
        public Objects wall100;
        public Objects wall101;
        public Objects wall102;
        public Objects wall103;
        public Objects wall104;
        public Objects wall105;
        public Objects wall106;
        public Objects wall107;
        public Objects wall108;
        public Objects wall109;
        public Objects wall110;
        public Objects wall111;
        public Objects wall112;
        public Objects wall113;

        public Objects wall200;
        public Objects wall201;
        public Objects wall202;
        public Objects wall203;
        public Objects wall204;
        public Objects wall205;
        public Objects wall206;
        public Objects wall207;
        public Objects wall208;
        public Objects wall209;
        public Objects wall210;
        public Objects wall211;
        public Objects wall212;
        public Objects wall213;

        StreamReader strm;
        string current;
        string[] currentDelimited;
        int levelNum;

        public Arena() : base()
        {
            levelNum = 1;
            current = "";
            wave = 1;
            rgen = new Random();
        }

        public override void CreateLevel()
        {
            drop = false;
            player = new Player(this, 450, 350, 64, 64, 100, 5);

            // vertical walls
            wall1 = new Objects(this, new Rectangle(0, 0, 64, 64), "grate");
            wall2 = new Objects(this, new Rectangle(0, 64, 64, 64), "grate");
            wall3 = new Objects(this, new Rectangle(0, 128, 64, 64), "grate");
            wall4 = new Objects(this, new Rectangle(0, 192, 64, 64), "grate");
            wall5 = new Objects(this, new Rectangle(0, 256, 64, 64), "grate");
            wall6 = new Objects(this, new Rectangle(0, 320, 64, 64), "grate");
            wall7 = new Objects(this, new Rectangle(0, 384, 64, 64), "grate");
            wall8 = new Objects(this, new Rectangle(0, 448, 64, 64), "grate");
            wall9 = new Objects(this, new Rectangle(0, 512, 64, 64), "grate");
            wall10 = new Objects(this, new Rectangle(0, 576, 64, 64), "grate");
            wall11 = new Objects(this, new Rectangle(0, 640, 64, 64), "grate");
            wall21 = new Objects(this, new Rectangle(960, 0, 64, 64), "grate");
            wall22 = new Objects(this, new Rectangle(960, 64, 64, 64), "grate");
            wall23 = new Objects(this, new Rectangle(960, 128, 64, 64), "grate");
            wall24 = new Objects(this, new Rectangle(960, 192, 64, 64), "grate");
            wall25 = new Objects(this, new Rectangle(960, 256, 64, 64), "grate");
            wall26 = new Objects(this, new Rectangle(960, 320, 64, 64), "grate");
            wall27 = new Objects(this, new Rectangle(960, 384, 64, 64), "grate");
            wall28 = new Objects(this, new Rectangle(960, 448, 64, 64), "grate");
            wall29 = new Objects(this, new Rectangle(960, 512, 64, 64), "grate");
            wall30 = new Objects(this, new Rectangle(960, 576, 64, 64), "grate");
            wall31 = new Objects(this, new Rectangle(960, 640, 64, 64), "grate");
            objs.Add(wall1);
            objs.Add(wall2);
            objs.Add(wall3);
            objs.Add(wall4);
            objs.Add(wall5);
            objs.Add(wall6);
            objs.Add(wall7);
            objs.Add(wall8);
            objs.Add(wall9);
            objs.Add(wall10);
            objs.Add(wall11);
            objs.Add(wall21);
            objs.Add(wall22);
            objs.Add(wall23);
            objs.Add(wall24);
            objs.Add(wall25);
            objs.Add(wall26);
            objs.Add(wall27);
            objs.Add(wall28);
            objs.Add(wall29);
            objs.Add(wall30);
            objs.Add(wall31);

            // horizontal walls
            wall100 = new Objects(this, new Rectangle(64, 0, 64, 64), "grate");
            wall101 = new Objects(this, new Rectangle(128, 0, 64, 64), "grate");
            wall102 = new Objects(this, new Rectangle(192, 0, 64, 64), "grate");
            wall103 = new Objects(this, new Rectangle(256, 0, 64, 64), "grate");
            wall104 = new Objects(this, new Rectangle(320, 0, 64, 64), "grate");
            wall105 = new Objects(this, new Rectangle(384, 0, 64, 64), "grate");
            wall106 = new Objects(this, new Rectangle(448, 0, 64, 64), "grate");
            wall107 = new Objects(this, new Rectangle(512, 0, 64, 64), "grate");
            wall108 = new Objects(this, new Rectangle(576, 0, 64, 64), "grate");
            wall109 = new Objects(this, new Rectangle(640, 0, 64, 64), "grate");
            wall110 = new Objects(this, new Rectangle(704, 0, 64, 64), "grate");
            wall111 = new Objects(this, new Rectangle(768, 0, 64, 64), "grate");
            wall112 = new Objects(this, new Rectangle(832, 0, 74, 64), "grate");
            wall113 = new Objects(this, new Rectangle(898, 0, 64, 64), "grate");
            wall200 = new Objects(this, new Rectangle(64, 640, 64, 64), "grate");
            wall201 = new Objects(this, new Rectangle(128, 640, 64, 64), "grate");
            wall202 = new Objects(this, new Rectangle(192, 640, 64, 64), "grate");
            wall203 = new Objects(this, new Rectangle(256, 640, 64, 64), "grate");
            wall204 = new Objects(this, new Rectangle(320, 640, 64, 64), "grate");
            wall205 = new Objects(this, new Rectangle(384, 640, 64, 64), "grate");
            wall206 = new Objects(this, new Rectangle(448, 640, 64, 64), "grate");
            wall207 = new Objects(this, new Rectangle(512, 640, 64, 64), "grate");
            wall208 = new Objects(this, new Rectangle(576, 640, 64, 64), "grate");
            wall209 = new Objects(this, new Rectangle(640, 640, 64, 64), "grate");
            wall210 = new Objects(this, new Rectangle(704, 640, 64, 64), "grate");
            wall211 = new Objects(this, new Rectangle(768, 640, 64, 64), "grate");
            wall212 = new Objects(this, new Rectangle(832, 640, 74, 64), "grate");
            wall213 = new Objects(this, new Rectangle(898, 640, 64, 64), "grate");
            objs.Add(wall100);
            objs.Add(wall101);
            objs.Add(wall102);
            objs.Add(wall103);
            objs.Add(wall104);
            objs.Add(wall105);
            objs.Add(wall106);
            objs.Add(wall107);
            objs.Add(wall108);
            objs.Add(wall109);
            objs.Add(wall110);
            objs.Add(wall111);
            objs.Add(wall112);
            objs.Add(wall113);
            objs.Add(wall200);
            objs.Add(wall201);
            objs.Add(wall202);
            objs.Add(wall203);
            objs.Add(wall204);
            objs.Add(wall205);
            objs.Add(wall206);
            objs.Add(wall207);
            objs.Add(wall208);
            objs.Add(wall209);
            objs.Add(wall210);
            objs.Add(wall211);
            objs.Add(wall212);
            objs.Add(wall213);

            // base.CreateLevel();
        }

        public override void Update()
        {
            // if player dies reset and load menu
            if (player.Health <= 0)
            {
                objs.Clear();
                enemies.Clear();
                projs.Clear();
                itemList.Clear();
                CreateLevel();
                wave = 1;
                player = new Player(this, 450, 350, 64, 64, 100, 5);
                base.Reset();
            }
            // checks if all enemies are gone and spawns new ones if they are and player is ready
            if (enemies.Count == 0 && player.ACheck())
            {
                LoadFile(1);
                
                //enemy1 = new Enemy(this, 128, 128, 64, 64, 10 + (wave * 10), 0, 1 + (wave * 2));
                //enemies.Add(enemy1);
                //wave2
                if (wave >= 2)
                {
                    LoadFile(2);
                    levelNum = 2;
                    //enemies.Add(new Enemy(this, 832, 128, 64, 64, 10 + (wave * 10), 1, 1 + (wave * 2)));
                }
                if(wave >= 3)
                {
                    LoadFile(3);
                    levelNum = 3;
                    //enemies.Add(new Enemy(this, 475, 128, 64, 64, 10 + (wave * 10), 1, 1 + (wave * 2)));
                }
                wave++;
                drop = false;
            }
            if(enemies.Count == 0 && wave > 1 && drop == false)
            {
                // generate random item for player every wave
                // roll health value 0 - 10
                int i1 = rgen.Next(0, 11);
                // speed value 0 - 1
                int i2 = rgen.Next(0, 2);
                // increases weapon damage 0 - 5
                int i3 = rgen.Next(0, 6);
                Items item = new Items(this, 475, 500, i1, i2, i3, "SpeedBoost");
                drop = true;
                itemList.Add(item);
            }
            base.Update();
        }

        public override void Load(ContentManager content)
        {
            if (levelNum == 1)
            {
                background = content.Load<Texture2D>("level1");
            }
            else if(levelNum == 2)
            {
                background = content.Load<Texture2D>("level2backup");
            }
            else if(levelNum == 3)
            {
                background = content.Load<Texture2D>("level3");
            }
            base.Load(content);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {

            spriteBatch.Draw(background, new Rectangle(64, 64, 1024, 768), Color.White);
            base.Draw(spriteBatch);
        }

        //method for loading custom files in
        public void LoadFile(int num)
        {
            strm = new StreamReader("level" + num + ".txt");
            current = strm.ReadLine();

            while (current != null)
            {
                currentDelimited = current.Split(',');
                switch (currentDelimited[0])
                {
                    case "Enemy1":
                        enemy1 = new Enemy(this, int.Parse(currentDelimited[1]), int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), int.Parse(currentDelimited[4]), int.Parse(currentDelimited[5]), int.Parse(currentDelimited[6]), 1 + (wave * 2));
                        enemies.Add(enemy1);
                        break;
                    case "Enemy2":
                        enemy2 = new Enemy(this, int.Parse(currentDelimited[1]), int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), int.Parse(currentDelimited[4]), int.Parse(currentDelimited[5]), int.Parse(currentDelimited[6]), 1 + (wave * 2));
                        enemy2.textureFileName = "Enemy2";
                        enemies.Add(enemy2);
                        break;
                    case "Enemy3":
                        enemy2 = new Enemy(this, int.Parse(currentDelimited[1]), int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), int.Parse(currentDelimited[4]), int.Parse(currentDelimited[5]), int.Parse(currentDelimited[6]), 1 + (wave * 2));
                        enemy2.textureFileName = "Enemy3";
                        enemies.Add(enemy2);
                        break;
                    case "structure":
                        objs.Add(new Objects(this, new Rectangle(int.Parse(currentDelimited[1]), int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), int.Parse(currentDelimited[4])), "grate"));
                        break;
                    case "Potion":
                        itemList.Add(new Items(this, int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), int.Parse(currentDelimited[1]), 0, 0, "SpeedBoost"));
                        break;
                    case "SpeedBoost":
                        itemList.Add(new Items(this, int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), 0, int.Parse(currentDelimited[1]), 0, "SpeedBoost"));
                        break;
                    case "DamageBuff":
                        itemList.Add(new Items(this, int.Parse(currentDelimited[2]), int.Parse(currentDelimited[3]), 0, 0, int.Parse(currentDelimited[1]), "SpeedBoost"));
                        break;
                    case "Weapon1":
                        break;
                    case "Weapon2":
                        break;
                    case "Weapon3":
                        break;
                    default:
                        break;
                }

                current = strm.ReadLine();
            }
        }
    }
}
