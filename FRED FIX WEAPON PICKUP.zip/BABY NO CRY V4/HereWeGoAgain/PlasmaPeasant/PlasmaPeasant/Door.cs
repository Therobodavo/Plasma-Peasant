﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace PlasmaPeasant
{
    class Door:Objects
    {
        // attribute
        private bool open;
        private Texture2D openTexture;
        private int nextRoom;
        private int nextX;
        private int nextY;
        private Arena game;

        // accessor
        public bool Open { get { return open; } set { open = value; } }
        public int NextRoom { get { return nextRoom; } }
        public int NextX { get { return nextX; } }
        public int NextY { get { return nextY; } }

        public Door(Arena lvl, Rectangle rectangle, int nxtRoom, int nextX, int nextY) : base(lvl,rectangle, "DoorClosed")
        {
            nextRoom = nxtRoom;
            open = false;
            this.nextX = nextX;
            this.nextY = nextY;
            game = lvl;
        }
        public override void Load(ContentManager content)
        {
            openTexture = content.Load<Texture2D>("DoorOpen");
            base.Load(content);
        }

        public override void Update()
        {
            if (open)
            {
                texture = openTexture;

                if (playerCollision())
                {
                    game.LevelNum = nextRoom;
                    game.NeedsLoaded = true;
                    game.NextX = this.NextX;
                    game.NextY = this.nextY;
                }
            }
            base.Update();
        }
        public bool playerCollision()
        {
            if (game.player.Rectangle.Intersects(rectangle))
            {
                return true;
            }
            return false;
        }
    }
}
