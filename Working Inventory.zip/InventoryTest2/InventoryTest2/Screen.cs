﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace InventoryTest2
{
    //Screen Class, lays out the basics for any advanced Screen Object
    class Screen
    {
        //checks if the screen needs reset
        protected bool needsReset;

        //Screen Constructor
        public Screen()
        {
            //initially says the screen doesn't need reset
            needsReset = false;
        }

        //Reset properties
        public bool NeedsReset
        {
            get { return needsReset; }
            set { needsReset = value; }
        }

        //Screen Load Method
        public virtual void Load(ContentManager content)
        {

        }

        //Screen Update Method
        public virtual void Update()
        {

        }

        //Screen Draw Method
        public virtual void Draw(SpriteBatch spriteBatch)
        {
            
        }

        //Screen reset Method
        public virtual void Reset()
        {

        }
    }
}
