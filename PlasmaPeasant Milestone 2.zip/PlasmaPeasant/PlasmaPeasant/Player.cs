﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
/*
 * GDAPS 2 Online Section 2
 * Player class
 * Programmed by Fred and David
 */
namespace PlasmaPeasant
{
    class Player:Characters
    {
        // attributes to save kyboard values
        KeyboardState kstate;
        KeyboardState oldstate;
        int lastPosX;
        int lastPosY;

        // accesor for kstate
        public KeyboardState Kstate { get { return kstate; } }

        // int value to set how often to shoot
        int shootval;

        // basic constructor
        public Player(Level lvl, int x, int y, int width, int height) : base(lvl, x, y, width, height)
        {
            shootval = 1000;
            fileTexture = "Peasant";
        }

        public void Control()
        {
            // save last keyboard state
            oldstate = kstate;

            //save last postion
            lastPosX = X;
            lastPosY = Y;

            //Input from user (moving and shooting)
            GetInput();

            //Checks if player collides
            if (lvl.CheckCollisionObjects(this))
            {
                X = lastPosX;
                Y = lastPosY;
            }
        }

        // shooting controls
        public bool Shoot()
        {
            // shooting controls
            if (shootval > 50)
            {
                if (kstate.IsKeyDown(Keys.Space))
                {
                    shootval = 0;
                    return true;
                }
                else
                {
                    shootval = shootval + 1;
                    return false;
                }
            }
            shootval = shootval + 1;
            return false;
        }
        public void GetInput()
        {

            if (kstate.IsKeyDown(Keys.Escape))
            {
                lvl.NeedsReset = true;
                Game1.currentScreen = Game1.GameStates.MainScreen;
            }
            // save keyboard state
            kstate = Keyboard.GetState();

            // movement controls
            if (kstate.IsKeyDown(Keys.W))
            {
                Y = Y - 5;
            }
            if (kstate.IsKeyDown(Keys.A))
            {
                X = X - 5;
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                Y = Y + 5;
            }
            if (kstate.IsKeyDown(Keys.D))
            {
                X = X + 5;
            }

            //Direction
            // code to figure out where player is aiming
            if (kstate.IsKeyDown(Keys.W))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Up_Left; }
                else if (kstate.IsKeyDown(Keys.D)) { motion = Direction.Up_Right; }
                else { motion = Direction.Up; }
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Down_Left; }
                else if (kstate.IsKeyDown(Keys.D)) { motion = Direction.Down_Right; }
                else { motion = Direction.Down; }
            }
            if (kstate.IsKeyDown(Keys.A) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { motion = Direction.Left; }
            if (kstate.IsKeyDown(Keys.D) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.A) == false) { motion = Direction.Right; }

            // if no keys are down shoots straight up
            if (kstate.IsKeyDown(Keys.A) == false && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { motion = Direction.Up; }

            if (Shoot())
            {
                lvl.projs.Add(new Projectile(lvl,this, new Rectangle(X, Y, 32, 32), 1, 0, 25, motion));
            }
        }

        public override void Update()
        {
            this.Control();
            base.Update();
        }
    }
}
