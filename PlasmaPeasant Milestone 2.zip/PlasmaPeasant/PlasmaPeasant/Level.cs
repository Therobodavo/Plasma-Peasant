﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
/*
 * GDAPS 2 Online Section 2
 * Level Class
 * Programmed by Fred and David
 */
namespace PlasmaPeasant
{
    class Level : Screen
    {
        // list to keep track of all objects
        public Player player;
        public List<Objects> objs = new List<Objects>();
        public List<Projectile> projs = new List<Projectile>();
        public ContentManager content;

        public Level():base()
        {
            CreateLevel();
        }

        public virtual void CreateLevel()
        {
            //create things here

        }

        // loads all objects in the lists
        public override void Load(ContentManager content)
        {
            this.content = content;

            for (int i = 0; i < projs.Count; i++)
            {
                projs[i].Load(content);
            }
            for (int i = 0; i < objs.Count; i++)
            {
                objs[i].Load(content);
            }
            player.Load(content);
        }

        //Updates everything 
        public override void Update()
        {
            for (int i = 0; i < projs.Count; i++)
            {
                projs[i].Update();
            }
            for (int i = 0; i < objs.Count; i++)
            {
                objs[i].Update();
            }
            player.Update();
        }

        // Draws everything
        public override void Draw(SpriteBatch spriteBatch)
        {
            //Loads everything incase of new objects being added since last load
            Load(content);

            //Draws everything
            for (int i = 0; i < projs.Count; i++)
            {
                projs[i].Draw(spriteBatch);
            }
            for (int i = 0; i < objs.Count; i++)
            {
                objs[i].Draw(spriteBatch);
            }
            player.Draw(spriteBatch);
        }

        //Method used to check collision (temporary)
        public bool CheckCollisionObjects(Objects objct)
        {
            foreach(Objects obj in objs)
            {
                if (objct.Rectangle.Intersects(obj.Rectangle)) { return true; }
            }
            return false;
        }
    }
}