﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
/*
 * GDAPS 2 Online Section 2
 * Characters Class
 * Programmed by Fred and David
 */
namespace PlasmaPeasant
{
    class Characters:Objects
    {
        // variables
        protected int health;
        protected int damage;

        // accessors
        public int Health { get { return health; } set { health = health + value; } }
        public int Damage { get { return damage; } set { damage = damage + value; } }

        //Constructors
        public Characters(Level lvl, int xloc, int yloc,int width, int height) : base(lvl, new Rectangle(xloc,yloc,width,height))
        {
            this.fileTexture = "enemy1";
        }
        public Characters(Level lvl, int xloc, int yloc, int width, int height, int health, int damage) : base(lvl, new Rectangle(xloc, yloc, width, height))
        {
            this.fileTexture = "enemy1";
            this.health = health;
            this.damage = damage;
        }
    }
}
