﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class Projectile : Objects
    {
        // attributes
        int damage;
        int despawn;
        int speed;

        // if id == 1 it came from player therefor doesn't damage him
        int id;

        // enum for direction
        enum Direction { Up, Up_Left, Left, Down_Left, Down, Down_Right, Right, Up_Right}
        Direction motion;

        public Projectile(Rectangle rec, int dmg, int travelTime) : base(rec)
        {
            // assigning variables
            damage = dmg;
            despawn = 1000;
            speed = travelTime;
            id = 0;
        }

        // overloaded constructor when for player projectiles
        public Projectile(Rectangle rec, int dmg, int travelTime, KeyboardState kstate):base(rec)
        {
            damage = dmg;
            despawn = 1000;
            speed = travelTime;
            // this constructor only called by player so id is always 1
            id = 1;

            // code to figure out where player is aiming
            if (kstate.IsKeyDown(Keys.W))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Up_Left; }
                if (kstate.IsKeyDown(Keys.D)) { X = X + speed; }
                else { }
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                Y = Y + speed;
                if (kstate.IsKeyDown(Keys.A)) { X = X - speed; }
                if (kstate.IsKeyDown(Keys.D)) { X = X + speed; }
            }

            // code to figure out where player is aiming
            if (kstate.IsKeyDown(Keys.W))
            {
                Y = Y - speed;
                if (kstate.IsKeyDown(Keys.A)) { X = X - speed; }
                if (kstate.IsKeyDown(Keys.D)) { X = X + speed; }
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                Y = Y + speed;
                if (kstate.IsKeyDown(Keys.A)) { X = X - speed; }
                if (kstate.IsKeyDown(Keys.D)) { X = X + speed; }
            }
        }
    }
}
