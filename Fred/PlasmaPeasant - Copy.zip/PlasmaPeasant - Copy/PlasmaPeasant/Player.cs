﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace PlasmaPeasant
{
    class Player:Characters
    {
        // attributes to save kyboard values
        KeyboardState kstate;
        Rectangle lastPos;
        List<Projectile> proj = new List<Projectile>();

        // accessor for projectiles
        public List<Projectile> Proj { get { return proj; } }

        // basic constructor
        public Player(int x, int y, int width, int height) : base(x, y, width, height) { proj = new List<Projectile>(); }

        public void Control()
        {
            //save last postion
            lastPos = Rectangle;

            // save keyboard state
            kstate = Keyboard.GetState();

            // movement controls
            if (kstate.IsKeyDown(Keys.W)) { Y = Y - 5; }
            if (kstate.IsKeyDown(Keys.A)) { X = X - 5; }
            if (kstate.IsKeyDown(Keys.S)) { Y = Y + 5; }
            if (kstate.IsKeyDown(Keys.D)) { X = X + 5; }
           
            // shooting controls
            if (kstate.IsKeyDown(Keys.Space)) { proj.Add(new Projectile(new Rectangle(X, Y, 32, 32), 1, 50, kstate)); }
        }
    }
}
