﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace PlasmaPeasant
{
    class Level : Screen
    {
        // list to keep track of all objects
        List<Objects> objs = new List<Objects>();
        List<Projectile> projs = new List<Projectile>();

        public Level()
        {
            objs.Add(new Objects(new Rectangle(250, 250, 128, 128),"ball"));
            objs.Add(new Objects(new Rectangle(150, 300, 32, 32), "ball"));
        }

        // method to check for intersection
        /****************************************************************
        public bool CheckCollision(Rectangle rec)
        {
            foreach (Objects obj in objs)
            {
                if (rec.Intersects(obj.Rectangle)) { return true; }
            }

            return false;
        }
        ******************************************************************/

        // loads all objects in the lists
        public void Loadlvl(ContentManager content)
        {
            foreach (Objects obj in objs)
            {
                obj.Load(content);
            }
            foreach (Projectile proj in projs)
            {
                proj.Load(content);
            }
        }

        // used to update locations of objects
        public void Updatelvl()
        {
            foreach(Projectile proj in projs)
            {
                proj;
            }
        }

        // Draws all objects in the lists
        public virtual void Drawlvl(SpriteBatch spriteBatch)
        {
            foreach(Objects obj in objs)
            {
                obj.Draw(spriteBatch);
            }
            foreach (Projectile proj in projs)
            {
                proj.Draw(spriteBatch);
            }
        }
    }
}