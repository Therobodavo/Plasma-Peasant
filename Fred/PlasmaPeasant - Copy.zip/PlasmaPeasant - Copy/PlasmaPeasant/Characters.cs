﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace PlasmaPeasant
{
    class Characters:Objects
    {
        // variables
        protected int health;
        protected int damage;

        // accessors
        public int Health { get { return health; } set { health = health + value; } }
        public int Damage { get { return damage; } set { damage = damage + value; } }

        public Characters(int xloc, int yloc,int width, int height) : base(new Rectangle(xloc,yloc,width,height)) { }
    }
}
