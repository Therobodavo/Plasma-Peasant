﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace PlasmaPeasant
{
    class Objects
    {
        // variables
        Texture2D texture;
        Rectangle rectangle;

        // string for saving texture name
        string fileTexture;

        //  accessors
        public Rectangle Rectangle { get { return rectangle; } }
        public Texture2D Texture { get { return texture; } set { texture = value; } }
        public int Width { get { return rectangle.Width; } }
        public int Height { get { return rectangle.Height; } }
        public int X { get { return rectangle.X; } set { rectangle.X = value; } }
        public int Y { get { return rectangle.Y; } set { rectangle.Y = value; } }

        public Objects(Rectangle rec)
        {
            rectangle = rec;
        }

        // other constructor to assign texture individually
        public Objects(Rectangle rec, string tex2D)
        {
            rectangle = rec;
            fileTexture = tex2D;
        }

        //Screen Load Method
        public virtual void Load(ContentManager content, string texture2d)
        {
            texture = content.Load<Texture2D>(texture2d);
        }
        
        //Screen Load Method
        public virtual void Load(ContentManager content)
        {
            texture = content.Load<Texture2D>(fileTexture);
        }

        //Screen Update Method
        public virtual void Update()
        {

        }

        //Screen Draw Method
        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectangle, Color.Cornsilk);
        }
    }
}
