﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * GDAPS 2 Online Section 2
 * Test Level Class (Will turn into first Dungeon class)
 * Programmed by David Knolls
 */
namespace PlasmaPeasant
{
    class TestLevel:Level
    {
        public TestLevel():base()
        {
            //Anything needed to run before CreateLevel
        }
        public override void CreateLevel()
        {
            
            player = new Player(this, 0, 0, 64, 64, 10, 5, 1);
            enemy1 = new Enemy(this, 300, 300, 64, 64, 5, 5, 5);
            enemies.Add(enemy1);
            // TEST ENEMY (smaller faster)
            enemy2 = new Enemy(this, 100, 200, 32, 32, 1, 10, 10);
            enemies.Add(enemy2);

            // TEST ITEM VALUES
            // 3rd int = Health Mutator
            // 4th int = Speed Mutator
            // 5th int = Damage Mutator
            itemTest = new Items(this, 250, 350, 10, 10, 10);
            itemList.Add(itemTest);

            try
            {   
                // Open the text file using a stream reader.
                StreamReader file = new StreamReader("TestLevel.txt");

                //variables used
                string line = "";
                string[] character;
                int[] newCharacter;

                //Read through file
                while ((line = file.ReadLine()) != null)
                {
                    //get each attribute
                    character = line.Split(',');
                    newCharacter = new int[character.Length];

                    //parse each attribute
                    for(int i = 0; i < character.Length; i++)
                    {
                        int.TryParse(character[i], out newCharacter[i]);
                    }

                    //Create object
                    // NEED TO ADD SPEED VARIABLE
                    // objs.Add(new Characters(this, newCharacter[2], newCharacter[3], newCharacter[4], newCharacter[5], newCharacter[0], newCharacter[1]));
                }
            }
            catch (Exception e)
            {
                
            }
            //objs.Add(new Objects(this, new Rectangle(250, 250, 128, 128)));
            //objs.Add(new Objects(this, new Rectangle(150, 300, 32, 32)));
            base.CreateLevel();
        }
        public override void Reset()
        {
            //Reset everything here
            objs.Clear();
            projs.Clear();
            CreateLevel();
            base.Reset();
        }
    }
}
