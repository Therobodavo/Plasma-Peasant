﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaPeasant
{
    class MeleeWeap:Weapon
    {
        public MeleeWeap(Characters host, Level lvl, int x, int y, int damage):base(host,lvl,x,y,damage)
        {
            
        }

    }
}
