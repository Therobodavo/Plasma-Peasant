﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace PlasmaPeasant
{
    class Player:Characters
    {
        // attributes to save kyboard values
        KeyboardState kstate;
        // enum value
        enum MoveState { Up, Left, Right, Down };
        MoveState mstate;

        // basic constructor
        public Player(int x, int y) : base(x, y) { }

        private void Move()
        {
            // saving keyboard state
            kstate = new KeyboardState();

            // changing mstate to track what direction character is moving
            if (kstate.IsKeyDown(Keys.W)) { mstate = MoveState.Up; }
            if (kstate.IsKeyDown(Keys.A)) { mstate = MoveState.Left; }
            if (kstate.IsKeyDown(Keys.S)) { mstate = MoveState.Down; }
            if (kstate.IsKeyDown(Keys.D)) { mstate = MoveState.Right; }

            switch (mstate)
            {
                case MoveState.Up: break;
                case MoveState.Left: break;
                case MoveState.Down: break;
                case MoveState.Right: break;
            }
        }
    }
}
