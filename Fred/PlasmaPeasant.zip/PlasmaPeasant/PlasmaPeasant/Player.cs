﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace PlasmaPeasant
{
    class Player:Characters
    {

        // attributes to save kyboard values
        KeyboardState kstate;
        KeyboardState oldstate;
        int lastPosX;
        int lastPosY;
        
        // string for finding where the player is looking
        string direct;
        // accessor for direction
        public string Direct { get { return direct; } }

        // accesor for kstate
        public KeyboardState Kstate { get { return kstate; } }

        // int value to set how often to shoot
        int shootval;
        // accessor for shooting
        public int ShootVal { get { return shootval; } set { shootval = shootval + value; } }

        // basic constructor
        public Player(Level lvl, int x, int y, int width, int height) : base(lvl, x, y, width, height) { shootval = 500; }

        public void Control()
        {
            // save last keyboard state
            oldstate = kstate;

            //save last postion
            lastPosX = X;
            lastPosY = Y;

            // save keyboard state
            kstate = Keyboard.GetState();

            // movement controls
            if (kstate.IsKeyDown(Keys.W)) { Y = Y - 5; }
            if (kstate.IsKeyDown(Keys.A)) { X = X - 5; }
            if (kstate.IsKeyDown(Keys.S)) { Y = Y + 5; }
            if (kstate.IsKeyDown(Keys.D)) { X = X + 5; }

            if (lvl.CheckCollisionObjects(this))
            {
                X = lastPosX;
                Y = lastPosY;
            }
        }

        // shooting controls
        public bool Shoot()
        {
            // figure out where play is aiming
            // code to figure out where player is aiming
            if (kstate.IsKeyDown(Keys.W))
            {
                if (kstate.IsKeyDown(Keys.A)) { direct = "Up_Left"; }
                else if (kstate.IsKeyDown(Keys.D)) { direct = "Up_Right"; }
                else { direct = "Up"; }
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                if (kstate.IsKeyDown(Keys.A)) { direct = "Down_Left"; }
                else if (kstate.IsKeyDown(Keys.D)) { direct = "Down_Right"; }
                else { direct = "Down"; }
            }
            if (kstate.IsKeyDown(Keys.A) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { direct = "Left"; }
            if (kstate.IsKeyDown(Keys.D) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.A) == false) { direct = "Right"; }

            // if no keys are down shoots straight up
            if (kstate.IsKeyDown(Keys.A) == false && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { direct = "Up"; }


            // shooting controls
            if (shootval > 50)
            {
                if (kstate.IsKeyDown(Keys.Space))
                {
                    shootval = 0;
                    return true;
                }
                else
                {
                    shootval = shootval + 1;
                    return false;
                }
            }

            shootval = shootval + 1;
            return false;
        }

        public override void Update()
        {
            this.Control();
        }
    }
}
