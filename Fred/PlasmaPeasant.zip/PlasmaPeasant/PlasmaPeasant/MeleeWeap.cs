﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaPeasant
{
    class MeleeWeap:Items
    {
        public MeleeWeap(Level lvl, int x, int y, int damage):base(lvl,x,y,0,damage,0)
        {

        }
    }
}
