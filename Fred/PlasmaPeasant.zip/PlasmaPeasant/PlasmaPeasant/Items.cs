﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaPeasant
{
    class Items
    {
        // item values
        int id;
        // take values to add to player
        int hpup;
        int dmgup;

        public Items(int i, int hp, int dmg)
        {
            id = i;
            hpup = hp;
            dmgup = dmg;
        }
    }
}
