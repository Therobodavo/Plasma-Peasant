﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class Items:Objects
    {

        // take values to add to player
        int health;
        int damage;
        int energy;

        public Items(Level lvl, int x, int y, int healthVal, int damageVal,int energyVal):base(lvl,new Rectangle(x,y,32,32))
        {
            health = healthVal;
            damage = damageVal;
            energy = energyVal;
        }

        // gets run if an item is picked up
        public void PickUp(Player play)
        {
            play.Health = health;
            // if health is above 100 set to 100
            if(play.Health > 100)
            {
                play.Health = 100 - play.Health;
            }
            play.Damage = damage;
            play.Energy = energy;
            // if energy is above 100 set to 100
            if (play.Energy > 100)
            {
                play.Energy = 100 - play.Energy;
            }
        }
    }
}
