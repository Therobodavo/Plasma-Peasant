﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class RangedWeap:Items
    {
        // int for projectile speed
        int speed;

        public RangedWeap(Level lvl,int x, int y, int damage, int projspeed):base(lvl,x,y,0,damage,0)
        {
            speed = projspeed;
        }

        // method for shooting weapon
        public Projectile Shoot(Player play)
        {
            // creates projectile from player location and view
            return new Projectile(lvl, new Rectangle(play.X, play.Y, 32, 32), 1, speed, play.Direct, "ball");

        }
    }
}
