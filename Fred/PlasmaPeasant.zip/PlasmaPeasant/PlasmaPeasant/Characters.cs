﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace PlasmaPeasant
{
    class Characters:Objects
    {
        // character attributes
        private int Health { get; set; }
        private int Dmg { get; set; }
        private int x { get; set; }
        private int y { get; set; }

        public Characters(int xloc, int yloc) : base(new Rectangle(xloc, yloc, 64, 64)) { }
    }
}
