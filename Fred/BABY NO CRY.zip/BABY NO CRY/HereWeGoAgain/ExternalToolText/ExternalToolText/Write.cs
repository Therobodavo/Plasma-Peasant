﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalToolText
{
    class Write
    {
        public void Writing(string type, StreamWriter strm, bool makeFile, string input, int result)
        {
            while(makeFile == true)
            {
                //get user input, write to file
                strm.Write(type + ",");

                /*unique name for object
                Console.Write("\nA name to identify this object/character: ");
                input = Console.ReadLine();
                strm.Write(input + ",");*/

                //write level
                /*Console.Write("\nName of level to put it in: ");
                input = Console.ReadLine();
                strm.Write(input + ",");*/

                //if type is a character
                if (type == "Enemy1" || type == "Enemy2" || type == "Enemy3")
                {
                    XAndY(input, result, strm);
                    strm.Write(",");
                    Width(input, result, strm);
                    strm.Write(",");
                    Height(input, result, strm);
                    strm.Write(",");
                    Health(input, result, strm);
                    goto MakeMore;
                }

                //weapons
                //ranged
                /*else if(type == "ranged")
                {
                    XAndY(input, result, strm);
                    strm.Write(",");
                    Damage(input, result, strm);
                    strm.Write(",");
                    ProjectileSpeed(input, result, strm);
                    goto MakeMore;                 
                }

                //melee
                else if (type == "melee")
                {
                    XAndY(input, result, strm);
                    strm.Write(",");
                    Damage(input, result, strm);
                    goto MakeMore;
                }*/
                //structure
                else if (type == "structure")
                {
                    XAndY(input, result, strm);
                    strm.Write(",");
                    Width(input, result, strm);
                    strm.Write(",");
                    Height(input, result, strm);
                    goto MakeMore;
                }
                //player wants to make item - potion, boost, or buff
                else if (type == "Potion" || input == "SpeedBoost" || input == "DamageBuff")
                {
                    Value(input, result, strm);
                    strm.Write(",");
                    XAndY(input, result, strm);                                      
                    goto MakeMore;
                }

                //items - weapons
                else if(input == "Weapon1" || input == "Weapon2" || input == "Weapon3")
                {
                    Damage(input, result, strm);
                    strm.Write(",");
                    XAndY(input, result, strm);
                    goto MakeMore;
                }

            //check to see if they want to keep adding to the file, line by line
            MakeMore:
                Console.Write("\nWould you like to add another " + type + " ('yes' or 'no'): ");
                input = Console.ReadLine();
                switch (input)
                {
                    case "yes": //loop
                        strm.WriteLine();
                        break;

                    case "no": //set done to true, leave loop
                        Console.WriteLine();
                        makeFile = false;
                        return;

                    default:
                        Console.WriteLine("\nTry again.");
                        goto MakeMore;
                }
            } //end inner loop
            Console.WriteLine("Something was wrong");          
        }

        //methods for getting values from input -------------------------------------------
        private void XAndY(string input, int result, StreamWriter strm)
        {   
            //get x and y values
            X:
            Console.Write("\nX Location: ");
            input = Console.ReadLine();
            if (int.TryParse(input, out result))
            {
                strm.Write(input + ",");
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto X;
            }

            Y:
            Console.Write("\nY Location: ");
            input = Console.ReadLine();
            if (int.TryParse(input, out result))
            {
                strm.Write(input);
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Y;
            }
        }

        /*private void Level(string input, StreamWriter strm)
        {
            Console.Write("\nName of level to put it in: ");
            input = Console.ReadLine();
            strm.Write(input);
        }*/

        private void ProjectileSpeed(string input, int result, StreamWriter strm)
        {
            ProjectileSpeed:
            Console.Write("\nProjectile Speed (0 - 50): ");
            input = Console.ReadLine();

            //make sure its an integer
            if (int.TryParse(input, out result))
            {
                if (result >= 0 && result <= 50)
                {
                    strm.Write(input);
                }
                else
                {
                    Console.WriteLine("\n0 to 50 please");
                    goto ProjectileSpeed;
                }
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto ProjectileSpeed;
            }
        }

        private void Damage(string input, int result, StreamWriter strm)
        {
            Damage:
            Console.Write("\nDamage (0 - 100): ");
            input = Console.ReadLine();

            //make sure its an integer
            if (int.TryParse(input, out result))
            {
                if (result >= 0 && result <= 100)
                {
                    strm.Write(input);
                }
                else
                {
                    Console.WriteLine("\n0 to 100 please");
                    goto Damage;
                }
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Damage;
            }
        }

        private void Width(string input, int result, StreamWriter strm)
        {
            Width:
            Console.Write("\nWidth: ");
            input = Console.ReadLine();
            if (int.TryParse(input, out result))
            {
                strm.Write(input);
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Width;
            }
        }

        private void Height(string input, int result, StreamWriter strm)
        {
            Height:
            Console.Write("\nHeight: ");
            input = Console.ReadLine();
            if (int.TryParse(input, out result))
            {
                strm.Write(input);
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Height;
            }
        }

        private void Health(string input, int result, StreamWriter strm)
        {
            Health:
            Console.Write("\nHealth (0 - 200): ");
            input = Console.ReadLine();

            //make sure its an integer
            if (int.TryParse(input, out result))
            {
                //check value
                if (result >= 0 && result <= 200)
                {
                    strm.Write(input);
                }
                else
                {
                    Console.WriteLine("\n0 to 200 please");
                    goto Health;
                }
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Health;
            }
        }

        /*private void Energy(string input, int result, StreamWriter strm)
        {
        Energy:
            Console.Write("\nEnergy (0 - 100): ");
            input = Console.ReadLine();

            //make sure its an integer
            if (int.TryParse(input, out result))
            {
                if (result >= 0 && result <= 100)
                {
                    strm.Write(input);
                }
                else
                {
                    Console.WriteLine("\n0 to 100 please");
                    goto Energy;
                }
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Energy;
            }
        }*/

        //can indicate what value with console.write before calling method. Can be used in general for other values.
        private void Value(string input, int result, StreamWriter strm)
        {
            Value:
            Console.Write("\nValue (0 - 100): ");
            input = Console.ReadLine();

            //make sure its an integer
            if (int.TryParse(input, out result))
            {
                if (result >= 0 && result <= 100)
                {
                    strm.Write(input);
                }
                else
                {
                    Console.WriteLine("\n0 to 100 please");
                    goto Value;
                }
            }
            else
            {
                Console.WriteLine("\nPlease enter a number.");
                goto Value;
            }
        }
    }
}
