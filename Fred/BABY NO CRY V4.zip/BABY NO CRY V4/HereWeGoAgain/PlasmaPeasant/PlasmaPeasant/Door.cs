﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace PlasmaPeasant
{
    class Door:Objects
    {
        // attribute
        private bool open;
        private string openTexture;
        private int nextRoom;

        // accessor
        public bool Open { get { return open; } set { open = value; } }
        public int NextRoom { get { return nextRoom; } }

        public Door(Level lvl, Rectangle rectangle,string closedTexture, int nxtRoom) : base(lvl,rectangle, closedTexture)
        {
            nextRoom = nxtRoom;
            open = false;
        }

        public override void Update()
        {
            if(open == true)
            {
                
            }
            base.Update();
        }
    }
}
