﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class Enemy:Characters
    {
        public Enemy(Level lvl, int x, int y, int width, int height) : base(lvl,x, y, width, height)
        {

        }
        
        public void Move()
        {

        }
    }
}
