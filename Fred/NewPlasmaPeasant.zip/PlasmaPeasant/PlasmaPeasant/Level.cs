﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace PlasmaPeasant
{
    class Level : Screen
    {
        // list to keep track of all objects
        public List<Player> players;
        public List<Enemy> enemies;
        public List<Objects> objs;
        public List<Projectile> projs;

        public Level()
        {
            // initalize lists
            players = new List<Player>();
            enemies = new List<Enemy>();
            objs = new List<Objects>();
            projs = new List<Projectile>();

            // test stuff
            players.Add(new Player(this, 0, 0, 64, 64));
            objs.Add(new Objects(this, new Rectangle(250, 250, 128, 128),"ball"));
            objs.Add(new Objects(this, new Rectangle(150, 300, 32, 32), "ball"));
        }

        // method to check for intersection
        /****************************************************************
        public bool CheckCollision(Rectangle rec)
        {
            foreach (Objects obj in objs)
            {
                if (rec.Intersects(obj.Rectangle)) { return true; }
            }

            return false;
        }
        ******************************************************************/

        // loads all objects in the lists
        public void Loadlvl(ContentManager content)
        {
            foreach(Player player in players)
            {
                player.Load(content,"Peasant");
            }
            foreach(Enemy enemy in enemies)
            {
                enemy.Load(content);
            }
            foreach (Objects obj in objs)
            {
                obj.Load(content);
            }
            foreach (Projectile proj in projs)
            {
                proj.Load(content);
            }
        }

        // used to update locations of objects
        public void Updatelvl(ContentManager content)
        {
            foreach(Player player in players)
            {
                player.Control();
                // check if player wants to shoot
                if (player.Shoot())
                {
                    projs.Add(new Projectile(this, new Rectangle(player.X, player.Y, 32, 32), 1, 0, 25, player.Kstate, "ball"));
                    foreach (Projectile proj in projs)
                    {
                        proj.Load(content);
                    }
                }
            }
            // checks projectile direction and shoots according to direction
            foreach(Projectile proj in projs)
            {
                proj.Update();
                // check if ready for despawn
                if (proj.Despawn())
                {
                    projs.Remove(proj);
                }
            }
        }

        // Draws all objects in the lists
        public void Drawlvl(SpriteBatch spriteBatch)
        {
            foreach (Player player in players)
            {
                player.Draw(spriteBatch);
            }
            foreach (Enemy enemy in enemies)
            {
                enemy.Draw(spriteBatch);
            }
            foreach (Objects obj in objs)
            {
                obj.Draw(spriteBatch);
            }
            foreach (Projectile proj in projs)
            {
                proj.Draw(spriteBatch);
            }
        }

        public bool CheckCollisionObjects(Objects objct)
        {
            foreach(Objects obj in objs)
            {
                if (objct.Rectangle.Intersects(obj.Rectangle)) { return true; }
            }
            return false;
        }
    }
}