﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PlasmaPeasant
{
    class Projectile : Objects
    {
        // attributes
        int damage;
        int despawn;
        int speed;

        // if id == 1 it came from player therefor doesn't damage him
        int id;

        // enum for direction
        enum Direction { Up, Up_Left, Left, Down_Left, Down, Down_Right, Right, Up_Right}
        Direction motion;

        public Projectile(Level lvl, Rectangle rec, int dmg, int desp, int travelTime, string texture) : base(lvl, rec, texture)
        {
            // assigning variables
            damage = dmg;
            despawn = desp;
            speed = travelTime;
            id = 0;
        }

        // overloaded constructor when for player projectiles
        public Projectile(Level lvl, Rectangle rec, int dmg, int desp, int travelTime, KeyboardState kstate, string texture):base(lvl, rec, texture)
        {
            damage = dmg;
            despawn = desp;
            speed = travelTime;
            // this constructor only called by player so id is always 1
            id = 1;

            // code to figure out where player is aiming
            if (kstate.IsKeyDown(Keys.W))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Up_Left; }
                else if (kstate.IsKeyDown(Keys.D)) { motion = Direction.Up_Right; }
                else { motion = Direction.Up; }
            }
            if (kstate.IsKeyDown(Keys.S))
            {
                if (kstate.IsKeyDown(Keys.A)) { motion = Direction.Down_Left; }
                else if (kstate.IsKeyDown(Keys.D)) { motion = Direction.Down_Right; }
                else { motion = Direction.Down; }
            }
            if (kstate.IsKeyDown(Keys.A) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { motion = Direction.Left; }
            if (kstate.IsKeyDown(Keys.D) && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.A) == false) { motion = Direction.Right; }

            // if no keys are down shoots straight up
            if (kstate.IsKeyDown(Keys.A) == false && kstate.IsKeyDown(Keys.W) == false && kstate.IsKeyDown(Keys.S) == false && kstate.IsKeyDown(Keys.D) == false) { motion = Direction.Up; }
        }

        // method to update projectile based on direction
        public override void Update()
        {
            if(motion == Direction.Up) { Y = Y - speed; }
            if(motion == Direction.Up_Left) { Y = Y - speed; X = X - speed; }
            if(motion == Direction.Up_Right) { Y = Y - speed; X = X + speed; }
            if(motion == Direction.Down) { Y = Y + speed; }
            if(motion == Direction.Down_Left) { Y = Y + speed; X = X - speed; }
            if(motion == Direction.Down_Right) { Y = Y + speed; X = X + speed; }
            if(motion == Direction.Left) { X = X - speed; }
            if(motion == Direction.Right) { X = X + speed; }

            // control number of projectiles
            despawn = despawn + 1;
        }

        // check if ready for despawn
        public bool Despawn()
        {
            if(despawn == 2000)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
